{
    'name': 'COC',
    'version': '16.0.1.0.0',
    'author': "Vishnuraj",
    'category': 'coc',
    'description': """ COC """,
    'depends': [
        'base', 'mail',
    ],

    'data': [
        'view/coc_four.xml',
    ],

    'license': 'LGPL-3',
    'installable': True,
    'application': True,
    'auto_install': False
}
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
